<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2>Image Gallery</h2>
                    <a href="" class="mr-5">Home</a>
                    <a href="" class="mr-5">Add Image</a>
                    <a href="<?php echo e(route('view-image')); ?>" class="mr-5">View Image</a>
                </div>

                <div class="card-body">

                        <div class="alert alert-success" role="alert">

                        </div>

                    <div>
                        <h2 class="text-center text-success"><?php echo e(Session::get('message')); ?></h2>
                        <form action="<?php echo e(route('upload-image')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>


                            <div class="form-group">
                                <label for="title">Image Title</label>
                                <input type="text" name="title" id="title" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="category" required>
                                    <option value="">Select Image Category</option>
                                    <option value="Personal Image">Personal Image</option>
                                    <option value="Family Image">Family Image</option>
                                    <option value="Friends Image">Friends Image</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="image">Image</label>
                                <input type="file" name="image" id="image" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Image Description</label>
                                <textarea type="text" name="description" id="description" class="form-control" required></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="btn" value="Submit" class="btn btn-block btn-danger">
                            </div>
                        </form>
                    </div>
                </div>
                
                
                    
                
                    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\imagegallery\resources\views/home.blade.php ENDPATH**/ ?>