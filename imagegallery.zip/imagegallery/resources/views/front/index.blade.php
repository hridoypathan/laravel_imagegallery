@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2>Image Gallery</h2>
                        <a href="" class="mr-5">Home</a>
                        <a href="{{ route('home') }}" class="mr-5">Add Image</a>
                        <a href="{{ route('view-image') }}" class="mr-5">View Image</a>
                    </div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div>
                            @foreach($images as $image)
                                <div class="card-footer">
                                    <div class="col-md-3 float-left"><img class="w-50 h-50" src="{{ asset($image->image) }}"></div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
