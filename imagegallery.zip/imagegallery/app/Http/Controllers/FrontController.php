<?php

namespace App\Http\Controllers;

use App\Front;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function uploadImage(Request $request){
        $images = new Front();

        $images->title = $request->title;
        $images->category = $request->value;
        $images->image = $request->image;
        $images->description = $request->description;
       $images->save();

        return redirect('/home')->with('message','Image Upload Successfully');
    }
    public function viewImage(){
        return view('front.index',[
            'images'  => Front::orderBy('id')->get(),
        ]);

    }
}
