<?php

namespace App\Http\Controllers;

use App\Front;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
//    public function index($id){
//        return view('home',[
//            'images'  => Front::where($id)->get()
//        ]);
//
//    }
}
