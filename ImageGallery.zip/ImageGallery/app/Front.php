<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Front extends Model
{
    public static function saveImage($request){
        $image      = $request->file('image');
        $imageName  = $image->getClientOriginalName();
        $location   ='ImageGallery/';
        $img        =$location.$imageName;
        $upload     = Front::where('image', $img)->first();
        if($upload){
            $date   =date('Y-m-d-H-i-s');
            $imageName  = $date.$imageName;
        }
        $image->move($location, $imageName);

        $newImage = new Front();
        $newImage->id                =$request->id;
        $newImage->title             =$request->title;
        $newImage->category          =$request->category;
        $newImage->image             =$location.$imageName;
        $newImage->description       =$request->description;
        $newImage->save();
    }
}
