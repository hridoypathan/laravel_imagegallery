<?php

namespace App\Http\Controllers;

use App\Front;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function uploadImage(Request $request){
        Front::saveImage($request);
        return redirect('/home')->with('message','Image Upload Successfully');
    }
    public function viewImage(){
        return view('front.index',[
            'images'  => Front::orderBy('id')->get(),
        ]);

    }
}
